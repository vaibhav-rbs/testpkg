'''
Created on June 26, 2013

@author: chw648
'''

import unittest
import sys, time
import android
import Camera

debug_tag  = 'MAP_DEBUG'
exception_tag = 'MAP_EXCEPTION'
error_tag = 'MAP_ERROR'


class TestMAPCamera(unittest.TestCase):

    def setUp(self):
        self.android    = android.connect()
        
        #Removing the try catch block
        self.android.ui.unlock()
        self.android.home.home()


    def tearDown(self):
        print "\n-------------------------------------------------------------"
        #time.sleep(android.settings.POST_LOOP_SLEEP)
        time.sleep(5)

        
    def test001CameraPhotoCapture(self):
        """Capturing photos through camera"""
        self.android.camera.launch_by_intent()
        self.android.camera.capture(3, False)
        

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
        
