import android
import unittest
import sys
import os, subprocess
import time
import datetime
import DeviceUtils
import MotdbUtils
import ICSUtils
import WSUtils
import CheckinUtils,BlurConfigUtils


content_variable = True

debug_tag  = 'DATASYS_DEBUG'
exception_tag = 'DATASYS_EXCEPTION'
error_tag = 'DATASYS_ERROR'
query_device_type = "update settings set value = \"PRODUCTION\""+\
                    "  where key = \"blur.service.checkin.device_type\""

'''
JBREL4-3C Mini-Regression Test-Case #CCE.CHECKIN:001-045

1). Initiate a checkin with #ELIOT#

Expected Results:(Verify Events Table for DEVICE_PROPERTIES)
'''
class TestVerifyDevicePropertiesAfterCheckinViaELIOT(unittest.TestCase):
    SUCCESS, FAIL = range(2)
    
    def setUp(self):        
        self.android    = android.connect()

        try:
            self.android.ui.unlock()
        except:
            pass
        
    def test001VerifyLogcat(self): 
        """Verify LogCat after Checkin via ELIOT"""
        print "\n Verify Logcat after Checkin thru #ELIOT#"
        try:
            self.android.deviceUtils.root_device()
            device_settings_db_fullpath = self.android.motdbUtils.getDbPath()
            db_exists = self.android.motdbUtils.checkIfDbExists(device_settings_db_fullpath)
            if db_exists:
                database_name = os.path.basename(device_settings_db_fullpath)
                ###Set Device type as production
                print "\nChanging device type to production"
                self.android.motdbUtils.updateTable(database_name,query_device_type)
                print "\nPushing the database"
                self.android.deviceUtils.pushFileToDevice(database_name,device_settings_db_fullpath)
                print "\nRebooting the device"
                self.android.deviceUtils.rebootDevice()   
            else:
                print "Database does not exist! Pulling blur_services_config.xml file"
                deviceTypeReturn=self.android.configUtils.isDeviceTypeProduction()
                if deviceTypeReturn:
                    ###If device type is Production
                    pass
                else:
                    ###Add the chekin_device_type tag and set value to PRODUCTION
                    self.android.configUtils.makeDeviceConfigTypeProduction()
 
            time.sleep(2)       

            print "\nCheckin with ELIOT"
            self.android.checkinUtils.doCheckInViaELIOT()
            print "\nWaiting for 4 minutes"
            time.sleep(240)
            
            print "\nVerifying DEVICE_PROPERTIES in Events Table"

            if self.android.motdbUtils.checkIfTagExistsInMotdb("events" , "DEVICE_PROPERTIES"):
                print "DEVICE_PROPERTIES Found - As Expected"
            else:
                raise self.failureException("Failed to get DEVICE_PROPERTIES")

        except Exception,e:
            print str(e)
            raise Exception ("\n  Exception in verifying DEVICE_PROPERTIES tags in the database")
            assert False, "Failed to do Logcat Verification"        
                   
    def tearDown(self):
        print "\n-------------------------------------------------------------"
        pass
        
                                                                      
if __name__ == '__main__':
    unittest.main()
